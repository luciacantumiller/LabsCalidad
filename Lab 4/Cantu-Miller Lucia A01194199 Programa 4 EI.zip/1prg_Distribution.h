#include <iostream>
#include <cmath>

class Distribution {
public:
	double Dist(double x, double dof);
private:
	double f; 
};

//.i
double Distribution::Dist(double x, double dof) { 
	f = (tgamma((dof + 1.0) / 2.0) / (pow(dof * 3.141593, 0.5) * tgamma(dof/2.0))) * (pow((1.0 + (pow(x, 2)/dof)),(dof + 1.0)/-2.0));
	return f;
}